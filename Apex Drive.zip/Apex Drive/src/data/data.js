import { get, post, put, del } from './request.js';

const endpoints = {
    all: '/data/cars?sortBy=_createdOn%20desc',
    byId: '/data/cars/',
    create: '/data/cars',
    edit: '/data/cars/',
    search: (query) => `/data/cars?where=model%20LIKE%20%22${query}%22`
}

async function getAll() {
    return get(endpoints.all);
}

async function getById(id) {
    return get(endpoints.byId + id);
}

async function create(data) {
    return post(endpoints.create, data);
}

async function update(id, record) {
    return put(endpoints.edit + id, record);
}

async function deleteById(id) {
    return del(endpoints.byId + id);
}

async function searchByQuery(query) {
    return get(endpoints.search(query));
    
}

export const dataService = {
    getAll,
    getById,
    getById,
    create,
    update,
    deleteById,
    searchByQuery
}