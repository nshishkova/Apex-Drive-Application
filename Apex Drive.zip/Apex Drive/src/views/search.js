import { html } from "../lib.js";
import { dataService } from "../data/data.js";

const temp = (cars) => html`      
        <section id="search">
          <div class="form">
            <h4>Search</h4>
            <form class="search-form" @submit=${onSubmit}>
              <input type="text" name="search" id="search-input" />
              <button class="button-list">Search</button>
            </form>
          </div>

          <div class="search-result">
            ${cars?.length
        ? cars.map(car => showTemp(car))
        :
        html`<h2 class="no-avaliable">No result.</h2>`
    } 

          </div>
        </section>`;

const showTemp = (car) => html`
        <div class="car">
            <img src=${car.imageUrl} alt="example1"/>
            <h3 class="model">${car.model}</h3>
            <a class="details-btn" href="/details/${car._id}">More Info</a>
        </div>
`

let context = null;
export function showSearchView(ctx) {
    ctx.render(temp());
    context = ctx;
}

async function onSubmit(e) {
    e.preventDefault();
    const formData = new FormData(e.target);

    const query = formData.get("search");
    if (!query.trim()) {
        return alert("Please fill the search field!");
    }

    const result = await dataService.searchByQuery(query);

    context.render(temp(result));
}